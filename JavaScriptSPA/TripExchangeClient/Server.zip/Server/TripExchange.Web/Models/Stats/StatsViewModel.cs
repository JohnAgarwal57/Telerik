﻿namespace TripExchange.Web.Models.Stats
{
    public class StatsViewModel
    {
        public int Trips { get; set; }

        public int FinishedTrips { get; set; }

        public int Users { get; set; }

        public int Drivers { get; set; }
    }
}