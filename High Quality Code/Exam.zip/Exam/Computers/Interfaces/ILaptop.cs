﻿namespace ComputerParts
{
    public interface ILaptop
    {
        void ChargeBattery(int percentage);
    }
}
