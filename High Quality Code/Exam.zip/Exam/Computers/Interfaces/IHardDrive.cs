﻿namespace ComputerParts
{
    public interface IHardDrive
    {
        int Capacity
        {
            get;
        }
    }
}
