﻿namespace ComputerParts
{
    public interface ICpu
    {
        string SquareNumber(int data);

        int Rand(int a, int b);
    }
}
