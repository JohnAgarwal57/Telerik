﻿namespace ComputerParts
{
    public interface IServer
    {
        void Process(int data);
    }
}
