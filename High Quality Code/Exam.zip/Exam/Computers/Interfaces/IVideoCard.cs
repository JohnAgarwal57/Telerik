﻿namespace ComputerParts
{
    public interface IVideoCard
    {
        void Draw(string message);
    }
}
