﻿namespace ComputerParts
{
    public interface IExtendedMotherBoard : IMotherboard, ICpu
    {
    }
}
