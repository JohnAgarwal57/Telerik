﻿namespace ComputerParts
{
    public interface IComputer
    {
        void Play(int number);
    }
}
